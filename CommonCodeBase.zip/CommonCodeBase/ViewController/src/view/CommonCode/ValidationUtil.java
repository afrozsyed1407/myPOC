package view.CommonCode;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ValidationUtil {
    public ValidationUtil() {
        super();
    }

    public static boolean isNullOrEmpty(String s) {
        return s == null ||
            (s != null && "".equals(s.trim()) || "null".equalsIgnoreCase(s.trim()));
    }

    public static boolean isNullOrEmpty(Object obj) {
        if (obj == null)
            return true;
        return isNullOrEmpty(obj.toString());
    }

    public static boolean isNullOrEmpty(List<?> list) {
        if (list == null)
            return true;
        return list.isEmpty();
    }
    
    public static boolean validateByRegex(String regex, String expression){
        boolean bValidated = false;
        if(!isNullOrEmpty(regex) && !isNullOrEmpty(expression)){
            Pattern pattern;
            Matcher matcher;
            pattern = Pattern.compile(regex);
            matcher = pattern.matcher(expression);
            bValidated = matcher.matches();
        }
        return bValidated;
    }
}
