package view.CommonCode;

import oracle.jbo.Row;

public class ModelUseUtil {
    public ModelUseUtil() {
        super();
    }
    
    
    // get a value from table TableXParameter
//    Create a entity object and view object of the table and have viewCriteria and BindValiable for it /*  */
 /*   public String getTableXParmValue(String paramName){
        Row row = null;
        String value = "";
        TableXParametersViewImpl tx = getTableXParametersView1();
        tx.setApplyViewCriteriaName("findByParameterName");
            tx.setNamedWhereClauseParm("bParamName",paramName);
            tx.executeQuery();
            if(tx.getRowCount()>0){
                row = tx.next();
                if(row != null){
                    value = (String)row.getAttribute("XParamValue");
                }
            }
            
        return value;
    }
    */
}
