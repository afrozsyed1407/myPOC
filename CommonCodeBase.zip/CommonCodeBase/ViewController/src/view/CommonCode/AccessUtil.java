package view.CommonCode;


import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import oracle.adf.share.ADFContext;

public class AccessUtil {
    public AccessUtil() {
        super();
    }
    
    // Get the current user's username
    public static String getCurrentUsername() {
      ADFContext adfContext = ADFContext.getCurrent();
      
      if (adfContext != null) {
        return adfContext.getSecurityContext().getUserName();
      }
      
      return null;
    }

    // Get the current user's role(s)    
    public static List<String> getCurrentUserRoles() {
      ADFContext adfContext = ADFContext.getCurrent();
      List<String> userRoles = new ArrayList<String>();

      if (adfContext != null) {
        String[] roles = adfContext.getSecurityContext().getUserRoles();
        for (String role : roles) {
          userRoles.add(role);
        }
      }

      return userRoles;
    }

    // Check if the current user has a specific role
    public static boolean hasUserRole(String role) {
      List<String> userRoles = getCurrentUserRoles();
      
      if (userRoles != null && role != null) {
        return userRoles.contains(role);
      }
      
      return false;
    }
    
    // Validate an email address
    public static boolean isValidEmail(String email) {
      if (email != null && !email.isEmpty()) {
        String emailRegex = "^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}$";
        Pattern pattern = Pattern.compile(emailRegex);
        Matcher matcher = pattern.matcher(email);
        return matcher.matches();
      }
      return false;
    }

    // Validate a password
    public static boolean isValidPassword(String password) {
      if (password != null && !password.isEmpty()) {
        // Add your password validation logic here
        // Example: Minimum length, must contain a combination of letters, numbers, and special characters
        return password.length() >= 8 && password.matches("^(?=.*[a-zA-Z])(?=.*\\d)(?=.*[@#$%^&+=!]).*$");
      }
      return false;
    }

    // Validate a phone number
    public static boolean isValidPhoneNumber(String phoneNumber) {
      if (phoneNumber != null && !phoneNumber.isEmpty()) {
        String phoneRegex = "^\\+?[0-9]{1,3}-?[0-9]{6,14}$";
        Pattern pattern = Pattern.compile(phoneRegex);
        Matcher matcher = pattern.matcher(phoneNumber);
        return matcher.matches();
      }
      return false;
    }
    
    // Validate a URL
    public static boolean isValidUrl(String url) {
      if (url != null && !url.isEmpty()) {
        String urlRegex = "^((http|https)://)?[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,6}(/[a-zA-Z0-9.-]*)*/?$";
        Pattern pattern = Pattern.compile(urlRegex);
        Matcher matcher = pattern.matcher(url);
        return matcher.matches();
      }
      return false;
    }

    // Validate a date in the format "yyyy-MM-dd"
    public static boolean isValidDate(String date) {
      if (date != null && !date.isEmpty()) {
        String dateRegex = "^(\\d{4})-(\\d{2})-(\\d{2})$";
        Pattern pattern = Pattern.compile(dateRegex);
        Matcher matcher = pattern.matcher(date);
        if (matcher.matches()) {
          int year = Integer.parseInt(matcher.group(1));
          int month = Integer.parseInt(matcher.group(2));
          int day = Integer.parseInt(matcher.group(3));
          return isValidDate(year, month, day);
        }
      }
      return false;
    }

    // Validate a date with year, month, and day values for java8
//    public static boolean isValidDate(int year, int month, int day) {
//      if (year >= 1 && month >= 1 && month <= 12 && day >= 1 && day <= 31) {
//        try {
//          LocalDate.of(year, month, day);
//          return true;
//        } catch (DateTimeException e) {
//          // Invalid date
//        }
//      }
//      return false;
//    }
    
    //validate date for java6
    public static boolean isValidDate(int year, int month, int day) {
            if (year >= 1 && month >= 1 && month <= 12 && day >= 1 && day <= 31) {
                try {
                    Calendar calendar = Calendar.getInstance();
                    calendar.setLenient(false);
                    calendar.set(year, month - 1, day);
                    calendar.getTime(); // Throws an exception for an invalid date
                    return true;
                } catch (Exception e) {
                    // Invalid date
                }
            }
            return false;
        }

    // Validate a credit card number using the Luhn algorithm
    public static boolean isValidCreditCardNumber(String cardNumber) {
      if (cardNumber != null && !cardNumber.isEmpty()) {
        cardNumber = cardNumber.replaceAll("\\s+", ""); // Remove whitespace
        int length = cardNumber.length();
        int sum = 0;
        boolean alternate = false;
        for (int i = length - 1; i >= 0; i--) {
          int digit = Character.getNumericValue(cardNumber.charAt(i));
          if (alternate) {
            digit *= 2;
            if (digit > 9) {
              digit -= 9;
            }
          }
          sum += digit;
          alternate = !alternate;
        }
        return sum % 10 == 0;
      }
      return false;
    }
    

    // Validate a social security number (SSN) in the format "XXX-XX-XXXX" or "XXXXXXXXX"
    public static boolean isValidSSN(String ssn) {
      if (ssn != null && !ssn.isEmpty()) {
        String ssnRegex = "^(\\d{3}-?\\d{2}-?\\d{4})|(\\d{9})$";
        Pattern pattern = Pattern.compile(ssnRegex);
        Matcher matcher = pattern.matcher(ssn);
        return matcher.matches();
      }
      return false;
    }

    // Validate a postal code based on a specific country format
    public static boolean isValidPostalCode(String postalCode, String countryCode) {
      if (postalCode != null && !postalCode.isEmpty() && countryCode != null && !countryCode.isEmpty()) {
        String postalCodeRegex = getPostalCodeRegexForCountry(countryCode);
        if (postalCodeRegex != null) {
          Pattern pattern = Pattern.compile(postalCodeRegex);
          Matcher matcher = pattern.matcher(postalCode);
          return matcher.matches();
        }
      }
      return false;
    }

    // Get the postal code regex pattern for a specific country
    private static String getPostalCodeRegexForCountry(String countryCode) {
      // Add your custom postal code regex patterns for different countries
      // Example:
      if (countryCode.equalsIgnoreCase("US")) {
        return "^\\d{5}(-\\d{4})?$"; // US postal code format: XXXXX or XXXXX-XXXX
      }
      return null;
    }

    // Validate a social media username (e.g., Twitter handle, Instagram username)
    public static boolean isValidSocialMediaUsername(String username) {
      if (username != null && !username.isEmpty()) {
        String usernameRegex = "^[a-zA-Z0-9._]+$";
        Pattern pattern = Pattern.compile(usernameRegex);
        Matcher matcher = pattern.matcher(username);
        return matcher.matches();
      }
      return false;
    }

    // Validate a file extension
    public static boolean isValidFileExtension(String fileName, String[] allowedExtensions) {
      if (fileName != null && !fileName.isEmpty() && allowedExtensions != null && allowedExtensions.length > 0) {
        String fileExtension = getFileExtension(fileName);
        if (fileExtension != null) {
          for (String allowedExtension : allowedExtensions) {
            if (fileExtension.equalsIgnoreCase(allowedExtension)) {
              return true;
            }
          }
        }
      }
      return false;
    }

    // Get the file extension from a file name
    private static String getFileExtension(String fileName) {
      if (fileName != null && !fileName.isEmpty()) {
        int dotIndex = fileName.lastIndexOf('.');
        if (dotIndex > 0 && dotIndex < fileName.length() - 1) {
          return fileName.substring(dotIndex + 1).toLowerCase();
        }
      }
      return null;
    }

}
