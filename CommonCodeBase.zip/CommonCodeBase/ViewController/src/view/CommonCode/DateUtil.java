package view.CommonCode;

import java.text.SimpleDateFormat;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class DateUtil {
    public DateUtil() {
        super();
    }
    
    // returns the days in between regardless of which dates start first
    
    public static int daysBetween(Calendar calendar1, Calendar calendar2){
        int daysBetween = 0;
        if(calendar1 == null || calendar2 == null) return daysBetween;
        
        Calendar beforeDate = (Calendar)calendar1.clone();
        Calendar afterDate = (Calendar)calendar2.clone();
        
        // nullify Time
        nullifyTime(beforeDate);
        nullifyTime(afterDate);
        
        if(beforeDate.after(afterDate)){
            beforeDate = afterDate;
            afterDate = (Calendar)calendar1.clone();
            nullifyTime(afterDate);
        }
        while(beforeDate.before(afterDate)){
            beforeDate.add(Calendar.DAY_OF_MONTH, 1);
            daysBetween++;
        }
        return daysBetween;
    }
    
    // another method to mind the difference between times
    public static int calculateDateDifference(Calendar date1, Calendar date2) {
            nullifyTime(date1);
            nullifyTime(date2);

            long milliseconds1 = date1.getTimeInMillis();
            long milliseconds2 = date2.getTimeInMillis();
            long diffMilliseconds = Math.abs(milliseconds2 - milliseconds1);

            int diffDays = (int) (diffMilliseconds / (24 * 60 * 60 * 1000));
            return diffDays;
        }
    
    // another method to mind the difference between times with Date as input
    public static int calculateDateDifference(Date date1, Date date2) {
            Calendar calendar1 = Calendar.getInstance();
            Calendar calendar2 = Calendar.getInstance();
            calendar1.setTime(date1);
            calendar2.setTime(date2);
            nullifyTime(calendar1);
            nullifyTime(calendar2);

            long milliseconds1 = calendar1.getTimeInMillis();
            long milliseconds2 = calendar2.getTimeInMillis();
            long diffMilliseconds = Math.abs(milliseconds2 - milliseconds1);

            int diffDays = (int) (diffMilliseconds / (24 * 60 * 60 * 1000));
            return diffDays;
        }
    
    

// Nullifies the time on the Calendar
    private static void nullifyTime(Calendar date) {
        date.set(Calendar.HOUR, 0);
        date.set(Calendar.MINUTE, 0);
        date.set(Calendar.SECOND, 0);
        date.set(Calendar.MILLISECOND, 0);
    }
    
    // returns days from today
    public static final int daysFromToday(Calendar endCalendar){
        Calendar fromCalender = GregorianCalendar.getInstance();
        Date fromTime = fromCalender.getTime();
        Date toTime = endCalendar.getTime();
        if(fromTime.after(toTime)){
            return 0;
        }
        return daysBetween(fromCalender,endCalendar);
    }
    
    // format date MM/dd/yy HH:mm:ss
//    public static String formatDate(Date date){
//        SimpleDateFormat format = new SimpleDateFormat("MM/dd/yy HH:mm:ss");
//        return format.format(date)
//    }
    
}
