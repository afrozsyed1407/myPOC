package view.CommonCode;


import java.util.Map;
import java.util.regex.Pattern;

import javax.el.ELContext;

import javax.el.ExpressionFactory;

import javax.el.ValueExpression;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;

import oracle.adf.model.BindingContext;
import oracle.adf.model.binding.DCBindingContainer;

import oracle.adf.model.binding.DCControlBinding;
import oracle.adf.model.binding.DCDataControl;
import oracle.adf.model.binding.DCIteratorBinding;
import oracle.adf.model.binding.DCIteratorBindingDef;
import oracle.adf.model.binding.DCParameter;

import oracle.adf.share.ADFContext;
import oracle.adf.share.logging.ADFLogger;

import oracle.adf.view.rich.component.rich.RichPopup;
import oracle.adf.view.rich.context.AdfFacesContext;
import oracle.adf.view.rich.util.ResetUtils;

import oracle.binding.AttributeBinding;

import oracle.binding.BindingContainer;

import oracle.binding.ControlBinding;

import oracle.binding.OperationBinding;

import oracle.jbo.ApplicationModule;
import oracle.jbo.ViewObject;
import oracle.jbo.uicli.binding.JUCtrlValueBinding;

public class ADFUtil {

    private static ADFLogger _logger =
        ADFLogger.createADFLogger(ADFUtil.class);

    public ADFUtil() {
        super();
    }

    // get application Module

    public static ApplicationModule getApplicationModuleForDataControl(String name) {
        return (ApplicationModule)JSFUtil.resolveExpression("#{data." + name +
                                                            ".dataProvider}");
    }

    public static Object getBoundedAttributeValue(String attributeName) {
        return findControlBinding(attributeName).getInputValue();
    }

    public static void setBoundedAttributeValue(String attributeName,
                                                Object value) {
        findControlBinding(attributeName).setInputValue(value);
    }

    public static Object getPageDefParameterValue(String pageDefName,
                                                  String parameterName) {
        BindingContainer bindings = findBindingContainer(pageDefName);
        DCParameter cParam =
            ((DCBindingContainer)bindings).findParameter(parameterName);
        return cParam.getValue();
    }

    public static AttributeBinding findControlBinding(String attributeName) {
        return findControlBinding(getBindingContainer(), attributeName);
    }

    public static BindingContainer getBindingContainer() {
        return (BindingContainer)JSFUtil.resolveExpression("#{bindings}");
    }

    public static AttributeBinding findControlBinding(BindingContainer bindingContainer,
                                                      String attributeName) {
        if (attributeName != null) {
            if (bindingContainer != null) {
                ControlBinding ctrlBinding =
                    bindingContainer.getControlBinding(attributeName);
                if (ctrlBinding instanceof AttributeBinding) {
                    return (AttributeBinding)ctrlBinding;
                }
            }
        }
        return null;
    }


    public static BindingContainer findBindingContainer(String pageDefName) {
        BindingContext bctx = getDCBindingContainer().getBindingContext();
        DCBindingContainer bindingContainer =
            bctx.findBindingContainer(pageDefName);
        return bindingContainer;
    }

    public static DCBindingContainer getDCBindingContainer() {
        return (DCBindingContainer)getBindingContainer();
    }

    public static DCIteratorBinding findIterator(String name) {
        DCIteratorBinding iter =
            getDCBindingContainer().findIteratorBinding(name);
        if (iter == null) {
            throw new RuntimeException("Iterator '" + name + "' not found");
        }
        return iter;
    }

    // Refresh the current iterator binding

    public static void refreshIteratorBinding(String iteratorName) {
        DCIteratorBinding iteratorBinding = findIterator(iteratorName);
        if (iteratorBinding != null) {
            iteratorBinding.executeQuery();
        }
    }


    public static DCIteratorBinding findIterator(String bindingContainer,
                                                 String iterator) {
        DCBindingContainer bindings =
            (DCBindingContainer)JSFUtil.resolveExpression("#{" +
                                                          bindingContainer +
                                                          "}");
        if (bindings == null) {
            throw new RuntimeException("Binding container '" +
                                       bindingContainer + "' not found");
        }
        DCIteratorBinding iter = bindings.findIteratorBinding(iterator);
        if (iter == null) {
            throw new RuntimeException("Iterator '" + bindingContainer +
                                       "' not found");
        }
        return iter;
    }

    public static JUCtrlValueBinding findCtrlBinding(String name) {
        JUCtrlValueBinding rowBinding =
            (JUCtrlValueBinding)getDCBindingContainer().findCtrlBinding(name);
        if (rowBinding == null) {
            throw new RuntimeException("CtrlBinding '" + name + "' not found");
        }
        return rowBinding;
    }

    public static OperationBinding findOperation(String name) {
        OperationBinding op =
            getDCBindingContainer().getOperationBinding(name);
        if (op == null) {
            throw new RuntimeException("Operation '" + name + "' not found");
        }
        return op;
    }

    public static OperationBinding findOperation(String bindingContainer,
                                                 String opName) {
        DCBindingContainer bindings =
            (DCBindingContainer)JSFUtil.resolveExpression("#{" +
                                                          bindingContainer +
                                                          "}");
        if (bindings == null) {
            throw new RuntimeException("Binding container '" +
                                       bindingContainer + "' not found");
        }
        OperationBinding op = bindings.getOperationBinding(opName);
        if (op == null) {
            throw new RuntimeException("Operation '" + opName + "' not found");
        }
        return op;
    }

    public static Object evaluateEL(String el) {
        FacesContext facesContext = FacesContext.getCurrentInstance();
        ELContext eLContext = facesContext.getELContext();
        ExpressionFactory expressionFactory =
            facesContext.getApplication().getExpressionFactory();
        ValueExpression exp =
            expressionFactory.createValueExpression(eLContext, el,
                                                    Object.class);
        return exp.getValue(eLContext);
    }

    public static void setEL(String el, Object val) {
        if (el != null && el.startsWith("#{bindings.}") &&
            (el.contains("attributeValue") || el.contains("inputValue"))) {
            String attrName = "";
            String attr[];
            attr = el.split(Pattern.quote("."));
            if (attr.length >= 2) {
                attrName = attr[1];
                setAttributeBindingValue(attrName, val);
            } else {
                _logger.info("Error setting El @@@ Invalid Attribute Name ---> " +
                             el);
            }
        } else {
            FacesContext facesContext = FacesContext.getCurrentInstance();
            ELContext elContext = facesContext.getELContext();
            ExpressionFactory expressionFactory =
                facesContext.getApplication().getExpressionFactory();
            ValueExpression exp =
                expressionFactory.createValueExpression(elContext, el,
                                                        Object.class);
            exp.setValue(elContext, val);
        }
    }

    public static void setAttributeBindingValue(String attrName, Object val) {
        BindingContainer bindingContainer =
            BindingContext.getCurrent().getCurrentBindingsEntry();
        oracle.adf.model.AttributeBinding attr =
            (oracle.adf.model.AttributeBinding)bindingContainer.getControlBinding(attrName);
        attr.setInputValue(val);
    }

    public static void setSessionScopeValue(String name, String value) {
        ADFContext adfCtx = ADFContext.getCurrent();
        Map sessionScope = adfCtx.getSessionScope();
        sessionScope.put(name, value);
    }

    public static String getSessionScopeValue(String name) {
        String value = null;
        ADFContext adfCtx = ADFContext.getCurrent();
        Map sessionScope = adfCtx.getSessionScope();
        value = (String)sessionScope.get(name);
        return value;
    }

    public static Object getPageFlowScopeValue(String name) {
        ADFContext adfCtx = ADFContext.getCurrent();
        Map pageFlowScope = adfCtx.getPageFlowScope();
        Object value = pageFlowScope.get(name);
        return value;
    }

    public static void setPageFlowScopeValue(String name, String value) {
        ADFContext.getCurrent().getPageFlowScope().put(name, value);
    }

    public static Object getRequestScopeValue(String name) {
        ADFContext adfCtx = ADFContext.getCurrent();
        Map requestScope = adfCtx.getRequestScope();
        Object value = requestScope.get(name);
        return value;
    }

    // Display a FacesMessage

    public static void addFacesMessage(String message,
                                       FacesMessage.Severity severity) {
        FacesContext facesContext = FacesContext.getCurrentInstance();
        FacesMessage facesMessage = new FacesMessage(severity, message, null);
        facesContext.addMessage(null, facesMessage);
    }

    // Show a popup

    public static void showPopup(String dialogId) {
        RichPopup.PopupHints hints = new RichPopup.PopupHints();
        RichPopup popup = findPopup(dialogId);
        if (popup != null) {
            popup.show(hints);
        }
    }

    // Hide a Popup

    public static void hidePopup(String dialogId) {
        RichPopup popup = findPopup(dialogId);
        if (popup != null) {
            popup.hide();
        }
    }

    // Find a RichPopup component by its ID

    public static RichPopup findPopup(String popupId) {
        FacesContext facesContext = FacesContext.getCurrentInstance();
        UIComponent component =
            facesContext.getViewRoot().findComponent(popupId);
        if (component instanceof RichPopup) {
            return (RichPopup)component;
        }
        return null;
    }

    // Get the current ADF data control

    public static DCDataControl getCurrentDataControl() {
        return getDCBindingContainer().getDataControl();
    }

    // Get the current ADF data control ID

    public static String getCurrentDataControlId() {
        return getCurrentDataControl().getName();
    }

    // Get the current ADF application module
    //    public static DCBindingContainer getCurrentApplicationModule() {
    //      return (DCBindingContainer) getCurrentDataControl().getRootApplicationModule();
    //    }

    // Get the current ADF application module name
    //    public static String getCurrentApplicationModuleName() {
    //      return getCurrentApplicationModule().getName();
    //    }

    // Get the current ADF view object iterator

    public static ViewObject getCurrentViewObject(String iteratorName) {
        DCIteratorBinding iteratorBinding = findIterator(iteratorName);
        if (iteratorBinding != null) {
            return iteratorBinding.getViewObject();
        }
        return null;
    }

    // Get the current ADF view object row count

    public static int getCurrentViewObjectRowCount(String iteratorName) {
        ViewObject viewObject = getCurrentViewObject(iteratorName);
        if (viewObject != null) {
            return viewObject.getRowCount();
        }
        return 0;
    }

    // Execute a method on the current ADF application module
    //    public static Object invokeMethodOnApplicationModule(String methodName, Object[] params, Class<?>[] paramTypes) {
    //      DCBindingContainer applicationModule = getCurrentApplicationModule();
    //      if (applicationModule != null) {
    //        return applicationModule.invokeOperation(methodName, params, paramTypes);
    //      }
    //      return null;
    //    }

    // Show a confirmation dialog and execute a method on confirmation

    public static void showConfirmationDialogAndExecute(String dialogId,
                                                        String methodName,
                                                        Object[] params,
                                                        Class<?>[] paramTypes) {
        showPopup(dialogId);
        // Set the method and its parameters to be executed on confirmation
        ADFContext.getCurrent().getPageFlowScope().put("confirmationMethod",
                                                       methodName);
        ADFContext.getCurrent().getPageFlowScope().put("confirmationParams",
                                                       params);
        ADFContext.getCurrent().getPageFlowScope().put("confirmationParamTypes",
                                                       paramTypes);
    }

    // Execute the method stored in the page flow scope as a confirmation action
    //    public static void executeConfirmationAction(DialogEvent dialogEvent) {
    //      String methodName = (String) ADFContext.getCurrent().getPageFlowScope().get("confirmationMethod");
    //      Object[] params = (Object[]) ADFContext.getCurrent().getPageFlowScope().get("confirmationParams");
    //      Class<?>[] paramTypes = (Class<?>[]) ADFContext.getCurrent().getPageFlowScope().get("confirmationParamTypes");
    //
    //      if (methodName != null) {
    //        invokeMethodOnApplicationModule(methodName, params, paramTypes);
    //      }
    //    }

    // Cancel the confirmation action and hide the dialog
    //    public static void cancelConfirmationAction(PopupCanceledEvent canceledEvent) {
    //      hideDialog(canceledEvent.getComponent().getClientId());
    //      // Clear the confirmation method and its parameters
    //      ADFContext.getCurrent().getPageFlowScope().put("confirmationMethod", null);
    //      ADFContext.getCurrent().getPageFlowScope().put("confirmationParams", null);
    //      ADFContext.getCurrent().getPageFlowScope().put("confirmationParamTypes", null);
    //    }

    // Get the current ADF task flow ID
    //    public static String getCurrentTaskFlowId() {
    //      AdfFacesContext adfFacesContext = AdfFacesContext.getCurrentInstance();
    //      return adfFacesContext.getViewRootData().getTaskFlowId();
    //    }

    // Get the current ADF task flow activity ID
    //    public static String getCurrentActivityId() {
    //      AdfFacesContext adfFacesContext = AdfFacesContext.getCurrentInstance();
    //      return adfFacesContext.getViewRootData().getActivityId();
    //    }

    // Save the ADF session state
    //    public static void saveSessionState() {
    //      DCSessionState sessionState = getCurrentDataControl().getSession().getState();
    //      sessionState.saveState();
    //    }

    // Restore the ADF session state
    //    public static void restoreSessionState() {
    //      DCSessionState sessionState = getCurrentDataControl().getSession().getState();
    //      sessionState.restoreState();
    //    }

    public static Object getELValue(String el) {
        FacesContext facesContext = FacesContext.getCurrentInstance();
        ELContext elContext = facesContext.getELContext();
        ExpressionFactory expressionFactory =
            facesContext.getApplication().getExpressionFactory();
        ValueExpression exp =
            expressionFactory.createValueExpression(elContext, el,
                                                    Object.class);
        return exp.getValue(elContext);
    }

    public static void setELValue(String el, Object val) {
        FacesContext facesContext = FacesContext.getCurrentInstance();
        ELContext elContext = facesContext.getELContext();
        ExpressionFactory expressionFactory =
            facesContext.getApplication().getExpressionFactory();
        ValueExpression exp =
            expressionFactory.createValueExpression(elContext, el,
                                                    Object.class);
        exp.setValue(elContext, val);
    }


}
