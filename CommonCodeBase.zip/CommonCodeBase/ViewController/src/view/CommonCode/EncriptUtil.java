package view.CommonCode;

public class EncriptUtil {
    public EncriptUtil() {
        super();
    }
    
    public static String encryptPassword(String strEnPwd){
        //variable declaration
        int len,i,i1;
        char c,cl;
        long l,l1;
        String s,s1,s2,s3,s4,scrambledMessage = "";
        
        //encript first character
        
        c= strEnPwd.charAt(0);
        l = (((c * 2 + 4 + 7 ) * 2 - 10 ) * 2 - 11);
        s= Long.toString(l);
        i=s.length();
        s1 = Integer.toString(i);
        scrambledMessage = s1+s;
        
        // encript the rest
        
        len = strEnPwd.length();
        for(int k = 1; k<len;k++){
            cl = strEnPwd.charAt(k);
            
            l1 = (((cl * 2 + 4 + 7 ) * 2 - 10 ) * 2 - 11);
            
            s2= Long.toString(l1);
            
            i1 = s2.length();
            s3 = Integer.toString(i1);
            
            s4 = Long.toString(l1);
            
            scrambledMessage = scrambledMessage+s3+s4;
            
        }
        return scrambledMessage;
    }
    
    
}
