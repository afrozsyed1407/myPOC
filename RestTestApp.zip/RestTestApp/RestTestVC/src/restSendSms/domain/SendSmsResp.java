package restSendSms.domain;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonIntegerFormatVisitor;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@Generated("jsonschema2pojo")
public class SendSmsResp {
    @JsonProperty("return")
    private Boolean _return;
    @JsonProperty("request_id")
    private String requestId;
    @JsonProperty("message")
    private List<String> message;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<String, Object>();

    @JsonProperty("return")
    public Boolean getReturn() {
    return _return;
    }

    @JsonProperty("return")
    public void setReturn(Boolean _return) {
    this._return = _return;
    }

    @JsonProperty("request_id")
    public String getRequestId() {
    return requestId;
    }

    @JsonProperty("request_id")
    public void setRequestId(String requestId) {
    this.requestId = requestId;
    }

    @JsonProperty("message")
    public List<String> getMessage() {
    return message;
    }

    @JsonProperty("message")
    public void setMessage(List<String> message) {
    this.message = message;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
    return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
    this.additionalProperties.put(name, value);
    }

    }
