package rest.mapper;

import java.util.HashMap;
import java.util.Map;

import restSendSms.domain.SendSmsResp;

public class RestCallMapper {
    public RestCallMapper() {
        super();
    }
    
    public static Map mapSendSmsResp(SendSmsResp sendSmsResp){
        Map responseMap = new HashMap();
        if(sendSmsResp!= null){
            try {
               responseMap.put("return", sendSmsResp.getReturn());
               responseMap.put("request_id", sendSmsResp.getRequestId());
               responseMap.put("message", sendSmsResp.getMessage());
           } catch (Exception e) {
                System.out.println("error occured in mapSendSmsResp::"+e);
            }
        }
        return responseMap;
    }
}
