package rest.client;

import com.fasterxml.jackson.databind.ObjectMapper;

import java.net.URI;

import java.util.Map;

import restSendSms.domain.SendSmsResp;
import restUtil.RestServicesUtil;

public class RestCallClient {
    public RestCallClient() {
        super();
    }
    
    
    public static SendSmsResp getSendSMSResp(Map<String, String> inputMap){
        SendSmsResp smsResp = new SendSmsResp();
        String myUrl = "https://www.fast2sms.com/dev/bulk?";
        URI baseURI;
        try {
            baseURI = new URI(myUrl);
            String jsonResponse = RestServicesUtil.doHttpGetRequest("RestCallClient.getSendSMSResp", baseURI, inputMap);
            if(jsonResponse!=null){
                ObjectMapper objectMapper = new ObjectMapper();
                smsResp = objectMapper.readValue(jsonResponse, SendSmsResp.class);
            }
            System.out.println("Printing response:::"+smsResp);
       } catch (Exception e) {
            System.out.println("Exception occured in RestCallClient.getSendSMSResp::"+e);
        }
        return smsResp;
    }
}
