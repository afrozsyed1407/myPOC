package rest.adapter;

import java.util.HashMap;
import java.util.Map;

import rest.client.RestCallClient;

import rest.mapper.RestCallMapper;

import restUtil.EmailTesting;

public class RestCallAdapter {
    public RestCallAdapter() {
        super();
    }
    
    // a test method to call the sms api
    
    public Map sendSms(Map<String, String> inputMap){
        System.out.println("Entered sendSMS adapter");
        
        Map result = new HashMap();
        if(inputMap != null){
            result = RestCallMapper.mapSendSmsResp(RestCallClient.getSendSMSResp(inputMap));
        }
        return result;
    }
    
    public String sendEmail(String toEmailAddress, String subject, String emailBody){
        String result="fail";
        System.out.println("Entered send email");
        String from = "emailtest.adf@gmail.com";
        result = EmailTesting.sendEmailService(from, toEmailAddress, subject, emailBody);
        return result;
    }
    
    private static void testSendSms(){
        HashMap<String, String> inputMap = new HashMap<String, String>();
        inputMap.put("authorization","lF4bH07urZYSUCiJQcGzaxnOP32hjtRdN1DwA5Vms9ykK6IMov2eafSlZq9UQg3WL574tocFdMTiN86s");
        inputMap.put("sender_id","TXTIND");
        inputMap.put("message","testing From ADF");
        inputMap.put("language","english");
        inputMap.put("route","p");
        inputMap.put("numbers","8096141026");
        RestCallAdapter restCallAdptr = new RestCallAdapter();
        Map resultMap = restCallAdptr.sendSms(inputMap);
        System.out.println("Result:::"+resultMap);

    }
    
    public static void main(String[] args) {
        testSendSms();
   }
}
