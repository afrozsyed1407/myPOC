package restUtil;

import java.io.BufferedReader;

import java.io.InputStreamReader;

import java.net.HttpURLConnection;
import java.net.URI;

import java.util.Map;

import javax.ws.rs.core.UriBuilder;

public class RestServicesUtil {
    public RestServicesUtil() {
        super();
    }
    //HTTP GET Request

    public static String doHttpGetRequest(String clientMethod, URI baseURI, Map<String, String> inputMap) {
        HttpURLConnection con = null;
        try {
            URI requestURI = baseURI;
            requestURI = buildURIWithParams(baseURI, inputMap);
            System.out.println(clientMethod + "  requestURI  " + requestURI);
            con = (HttpURLConnection) requestURI.toURL().openConnection();
            con.setRequestMethod("GET");
            con.setRequestProperty("Content-Type", "application/json");
            con.setRequestProperty("Accept", "application/json");

            int responseCode = con.getResponseCode();
            if (responseCode == HttpURLConnection.HTTP_OK) {
                BufferedReader reader = new BufferedReader(new InputStreamReader(con.getInputStream()));
                String inputLine;
                StringBuilder response = new StringBuilder();
                while ((inputLine = reader.readLine()) != null) {
                    response.append(inputLine);
                }
                reader.close();
                return response.toString();
            } else
                System.out.println(clientMethod + " failed with response code ::" + responseCode);

        } catch (Exception e) {
            System.out.println("exception occured::" + e);
        } finally {
            if (con != null)
                con.disconnect();
        }
        return "";
    }

    private static URI buildURIWithParams(URI baseURI, Map<String, String> inputMap) {
        URI finalURI = baseURI;
        if (inputMap != null) {
            try {
                UriBuilder uriBuilder = UriBuilder.fromUri(baseURI.toString());
                for (Map.Entry<String, String> entry : inputMap.entrySet()) {
                    uriBuilder.queryParam(entry.getKey(), entry.getValue());
                }
                finalURI = uriBuilder.build();
            } catch (Exception e) {
                System.out.println("Exception in buildURIWithParams:: " + e);
            }
        }
        return finalURI;
    }

    public static String doHttpPostRequest(String clientMethod, String urlString, String jsonPostData) {
        String response = "";
        HttpURLConnection con = null;
        int responseCode = 0;
        try {
            URI requestURI = new URI(urlString);
            con = (HttpURLConnection) requestURI.toURL().openConnection();
            con.setDoOutput(true);
            con.setDoInput(true);
            con.setRequestMethod("POST");
            con.setRequestProperty("Content-Type", "application/json");
            con.setRequestProperty("Accept", "application/json");

            // send POST DATA
            byte[] postDataBytes = jsonPostData.getBytes("UTF-8");
            con.setRequestProperty("Content-Length", String.valueOf(postDataBytes.length));
            con.getOutputStream().write(postDataBytes);
            responseCode = con.getResponseCode();
            System.out.println("responseCode::" + responseCode);
            BufferedReader reader =
                new BufferedReader(new InputStreamReader((responseCode == HttpURLConnection.HTTP_OK) ?
                                                         con.getInputStream() : con.getErrorStream()));
            String inputLine;
            StringBuffer strResponse = new StringBuffer();
            while ((inputLine = reader.readLine()) != null) {
                strResponse.append(inputLine);
            }
            reader.close();
            response = strResponse.toString();
            ;
        } catch (Exception e) {
            System.out.println(clientMethod + " Exception Occurred::" + e);
            if (responseCode == 201)
                response = "Success";
        } finally {
            if (con != null)
                con.disconnect();
        }
        return response;
    }
    
    // HTTP PUT request
    public static String doHttpPutRequest(String clientMethod, String urlString, String jsonPostData) {
        String response = "";
        HttpURLConnection con = null;
        int responseCode = 0;
        try {
            URI requestURI = new URI(urlString);
            con = (HttpURLConnection) requestURI.toURL().openConnection();
            con.setDoOutput(true);
            con.setDoInput(true);
            con.setRequestMethod("PUT");
            con.setRequestProperty("Content-Type", "application/json");
            con.setRequestProperty("Accept", "application/json");

            // send DATA
            byte[] postDataBytes = jsonPostData.getBytes("UTF-8");
            con.setRequestProperty("Content-Length", String.valueOf(postDataBytes.length));
            con.getOutputStream().write(postDataBytes);
            responseCode = con.getResponseCode();
            System.out.println("responseCode::" + responseCode);
            BufferedReader reader =
                new BufferedReader(new InputStreamReader((responseCode == HttpURLConnection.HTTP_OK) ?
                                                         con.getInputStream() : con.getErrorStream()));
            String inputLine;
            StringBuffer strResponse = new StringBuffer();
            while ((inputLine = reader.readLine()) != null) {
                strResponse.append(inputLine);
            }
            reader.close();
            response = strResponse.toString();
            ;
        } catch (Exception e) {
            System.out.println(clientMethod + " Exception Occurred::" + e);
            if (responseCode == 201)
                response = "Success";
        } finally {
            if (con != null)
                con.disconnect();
        }
        return response;
    }
    
    // HTTP DELETE request
    public static String doHttpDeleteRequest(String clientMethod, String urlString, String jsonPostData) {
        String response = "";
        HttpURLConnection con = null;
        int responseCode = 0;
        try {
            URI requestURI = new URI(urlString);
            con = (HttpURLConnection) requestURI.toURL().openConnection();
            con.setDoOutput(true);
            con.setDoInput(true);
            con.setRequestMethod("POST");
            con.setRequestProperty("X-HTTP-Method-Override", "DELETE");
            con.setRequestProperty("Content-Type", "application/json");
            con.setRequestProperty("Accept", "application/json");

            // send POST DATA
            byte[] postDataBytes = jsonPostData.getBytes("UTF-8");
            con.setRequestProperty("Content-Length", String.valueOf(postDataBytes.length));
            con.getOutputStream().write(postDataBytes);
            responseCode = con.getResponseCode();
            System.out.println("responseCode::" + responseCode);
            BufferedReader reader =
                new BufferedReader(new InputStreamReader((responseCode == HttpURLConnection.HTTP_OK) ?
                                                         con.getInputStream() : con.getErrorStream()));
            String inputLine;
            StringBuffer strResponse = new StringBuffer();
            while ((inputLine = reader.readLine()) != null) {
                strResponse.append(inputLine);
            }
            reader.close();
            response = strResponse.toString();
            ;
        } catch (Exception e) {
            System.out.println(clientMethod + " Exception Occurred::" + e);
            if (responseCode == 201)
                response = "Success";
        } finally {
            if (con != null)
                con.disconnect();
        }
        return response;
    }
    
    // HTTP DELETE request with query(URL)parameter request
    public static String doHttpDeleteWithQueryParam(String clientMethod, URI baseURI, Map<String, String> inputMap) {
        HttpURLConnection con = null;
        try {
            URI requestURI = baseURI;
            requestURI = buildURIWithParams(baseURI,inputMap);
            System.out.println(clientMethod + " Request URI ::"+ requestURI);
            con = (HttpURLConnection) requestURI.toURL().openConnection();
            con.setRequestMethod("DELETE");
            con.setRequestProperty("Content-Type", "application/json");
            con.setRequestProperty("Accept", "application/json");

            int responseCode = con.getResponseCode();
            if (responseCode == HttpURLConnection.HTTP_OK) {
                BufferedReader reader = new BufferedReader(new InputStreamReader(con.getInputStream()));
                String inputLine;
                StringBuilder response = new StringBuilder();
                while ((inputLine = reader.readLine()) != null) {
                    response.append(inputLine);
                }
                reader.close();
                return response.toString();
            } else
                System.out.println(clientMethod + " failed with response code ::" + responseCode);
        } catch (Exception e) {
            System.out.println(clientMethod + " Exception Occurred::" + e);
            
        } finally {
            if (con != null)
                con.disconnect();
        }
        return "";
    }
}
