package restUtil;

import java.util.Date;
import java.util.Properties;

import javax.mail.Authenticator;
import javax.mail.Session;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Transport;

public class EmailTesting {
    public EmailTesting() {
        super();
    }

    public static String sendEmailService(String fromEmailAddress, String toEmailAddress, String subject,
                                        String emailBody) {

        try {
            String mailServerHost = "smtp.gmail.com";
            String mailPort = "587";

            //Configuring SMTP server details
            Properties props = new Properties();
            props.put("mail.smtp.auth", true);
            props.put("mail.smtp.starttls.enable", true);
            props.put("mail.smtp.port", mailPort);
            props.put("mail.smtp.host", mailServerHost);
            //            props.setProperty("mail.smtp.host", mailServerHost);


//            String userName = "______________";//your email id
//            String password = "______________";// your app password from gmail

            String userName = "emailtest.adf"; //your email id
            String password = "ocjlkfxommwwmwnm"; // your app password from gmail
            // creating session
            

            Session session = Session.getInstance(props, new Authenticator() {
                @Override
                protected PasswordAuthentication getPasswordAuthentication() {
                    return new PasswordAuthentication(userName, password);
                }
            });


            // test data
            //            String fromEmailAddress =  "emailtest.adf@gmail.com";
            //            String toEmailAddress =  "afrozsyed350@gmail.com";
            //            String emailBody = "Test Mail from ADF.. Sent by Afroz";
            //            String subject = "Mail from ADF";


            // creating MimeMessage which is implementation of Message class to send email
            MimeMessage mailMessage = new MimeMessage(session);
            mailMessage.setSentDate(new Date());
            mailMessage.setFrom(new InternetAddress(fromEmailAddress));
            mailMessage.addRecipient(Message.RecipientType.TO, new InternetAddress(toEmailAddress));
            mailMessage.setHeader("Content-Transfer-Encoding", "quoted-printable");
            mailMessage.setContent(emailBody, "text/html; charset=\"iso8859-1\"");
            mailMessage.setSubject(subject);


            // sending Mail
            Transport.send(mailMessage);
            System.out.println("Email Sent Sucessfully");
            return "Success. send mail";


        } catch (Exception e) {
            System.out.println("Exception Occured::::" + e);
        }
        return "failed send Mail";
    }

    public static void main(String[] args) {
        String fromEmailAddress = "emailtest.adf@gmail.com";
        String toEmailAddress = "rajesh.ch5892@gmail.com";
        String subject = "Mail from ADF";
        String emailBody = "Test Mail from ADF.. Sent by Afroz";
        
        
//        String userName = "emailtest.adf";//your email id
//        String password = "ocjlkfxommwwmwnm";// your app password from gmail
        sendEmailService(fromEmailAddress, toEmailAddress, subject, emailBody);
    }
}
