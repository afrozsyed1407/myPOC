package view.bean;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import java.io.InputStream;

import javax.faces.context.FacesContext;
import javax.faces.event.ValueChangeEvent;

import oracle.adf.model.BindingContext;

import oracle.adf.view.rich.component.rich.input.RichInputText;
import oracle.adf.view.rich.util.ResetUtils;

import oracle.binding.BindingContainer;

import oracle.binding.OperationBinding;

import org.apache.myfaces.trinidad.model.UploadedFile;

public class myBean {
    private RichInputText pathBind;

    public myBean() {
    }
    public String uploadFile(UploadedFile file){
        UploadedFile myfile = file;
                String path = null;
                if (myfile == null) {

                } else {
                    // All uploaded files will be stored in below path
                    path = "D://FileStore//" + myfile.getFilename();
                    InputStream inputStream = null;
                    try {
                        FileOutputStream out = new FileOutputStream(path);
                        inputStream = myfile.getInputStream();
                        byte[] buffer = new byte[8192];
                        int bytesRead = 0;
                        while ((bytesRead = inputStream.read(buffer, 0, 8192)) != -1) {
                            out.write(buffer, 0, bytesRead);
                        }
                        out.flush();
                        out.close();
                    } catch (Exception ex) {
                        // handle exception
                        ex.printStackTrace();
                    } finally {
                        try {
                            inputStream.close();
                        } catch (IOException e) {
                        }
                    }

                }
                //Returns the path where file is stored
                return path;
    }
    public void uploadFileVCL(ValueChangeEvent valueChangeEvent) {
        System.out.println("inside VCL");
        if (valueChangeEvent.getNewValue() != null) {
            System.out.println("file is not null");
                   //Get File Object from VC Event
                   UploadedFile fileVal = (UploadedFile) valueChangeEvent.getNewValue();
                   //Upload File to path- Return actual server path
                   String path = uploadFile(fileVal);
                   System.out.println(fileVal.getContentType());
                   //Method to insert data in table to keep track of uploaded files
                   BindingContext bctx = BindingContext.getCurrent();
                   BindingContainer bc = bctx.getCurrentBindingsEntry();
                   OperationBinding ob = bc.getOperationBinding("setFileDate");
                   ob.getParamsMap().put("name", fileVal.getFilename());
                   ob.getParamsMap().put("path", path);
                   ob.getParamsMap().put("contTyp", fileVal.getContentType());
                   ob.execute();
                   // Reset inputFile component after upload
                   ResetUtils.reset(valueChangeEvent.getComponent());
    }
    }

    public void downloadFileAL(FacesContext facesContext,
                               java.io.OutputStream outputStream) throws IOException {
        //Read file from particular path, path bind is binding of table field that contains path
               File filed = new File(pathBind.getValue().toString());
               FileInputStream fis;
               byte[] b;
               try {
                   fis = new FileInputStream(filed);

                   int n;
                   while ((n = fis.available()) > 0) {
                       b = new byte[n];
                       int result = fis.read(b);
                       outputStream.write(b, 0, b.length);
                       if (result == -1)
                           break;
                   }
               } catch (IOException e) {
                   e.printStackTrace();
               }
               outputStream.flush();
    }

    public void setPathBind(RichInputText pathBind) {
        this.pathBind = pathBind;
    }

    public RichInputText getPathBind() {
        return pathBind;
    }
}
