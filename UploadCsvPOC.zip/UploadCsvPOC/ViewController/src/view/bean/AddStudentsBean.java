package view.bean;

import java.io.InputStream;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.event.ValueChangeEvent;

import oracle.adf.model.BindingContext;
import oracle.adf.model.adapter.dataformat.csv.CSVParser;
import oracle.adf.model.binding.DCBindingContainer;
import oracle.adf.view.rich.component.rich.input.RichInputFile;

import oracle.jbo.Row;
import oracle.jbo.server.ViewObjectImpl;

import org.apache.myfaces.trinidad.model.UploadedFile;

public class AddStudentsBean {
    private RichInputFile fileUploadBind;

    public AddStudentsBean() {
    }

    public void setFileUploadBind(RichInputFile fileUploadBind) {
        this.fileUploadBind = fileUploadBind;
    }

    public RichInputFile getFileUploadBind() {
        return fileUploadBind;
    }
    
    public void inputFileVCL(ValueChangeEvent valueChangeEvent) {
        System.out.println("entered vcl");
        InputStream inputstream = null;
        try{
            UploadedFile file = (UploadedFile)valueChangeEvent.getNewValue();
            inputstream = file.getInputStream();
            String filename = file.getFilename().toString();
            filename = filename.toLowerCase();
            System.out.println("fileName::"+filename);
            if(!filename.endsWith(".csv")){
                System.out.println("not a proper file");
                FacesContext context = FacesContext.getCurrentInstance();
                context.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, " Upload CSV file only..", null));
                this.getFileUploadBind().resetValue();
            }
            else{
                CSVParser csvParser;
                csvParser = new CSVParser(inputstream);
                //csvParser.nextLine();
                while(csvParser.nextLine()){
                    String[] lineValue = csvParser.getLineValues();
                    if(!this.parse(lineValue)){
                        return;
                    }
                }
                this.getFileUploadBind().resetValue();
            }
        }catch(Exception ex){
            System.out.println("error:::"+ex);
        }
       
    }
    
    public boolean parse(String[] lines){
        System.out.println("inside parse line method");
        if(lines.length>0){
            // calling the vo from iterator
            DCBindingContainer dc = (DCBindingContainer)BindingContext.getCurrent().getCurrentBindingsEntry();
            ViewObjectImpl vo = (ViewObjectImpl)dc.findIteratorBinding("StudentsPVO1Iterator").getViewObject();
            System.out.println("Student Id: "+lines[0]);
            System.out.println("Name: "+lines[1]);
            System.out.println("Class: "+lines[2]);
            Row r = vo.createRow(); // creating row
            // setting the values
            r.setAttribute("StudentId", lines[0]);
            r.setAttribute("Name", lines[1]);
            r.setAttribute("ClassName", lines[2]);
            vo.insertRowAtRangeIndex(vo.getRowCount(), r);
            vo.setCurrentRow(r);
        }
      return true;  
    }

    public void clearTableAL(ActionEvent actionEvent) {
        DCBindingContainer dc = (DCBindingContainer)BindingContext.getCurrent().getCurrentBindingsEntry();
        ViewObjectImpl vo = (ViewObjectImpl)dc.findIteratorBinding("StudentsPVO1Iterator").getViewObject();
        vo.executeQuery();
    }
}
