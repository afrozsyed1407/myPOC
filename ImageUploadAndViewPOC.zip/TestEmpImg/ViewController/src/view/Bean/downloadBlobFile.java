package view.Bean;

import java.io.IOException;
import java.io.OutputStream;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;

import oracle.adf.model.BindingContext;

import oracle.binding.AttributeBinding;
import oracle.binding.BindingContainer;

import oracle.jbo.domain.BlobDomain;

import org.apache.commons.io.IOUtils;


public class downloadBlobFile {
    public downloadBlobFile(){
        }
    public void downloadBlobFile(FacesContext facesContext,OutputStream outputStream){
        BindingContainer bindings = BindingContext.getCurrent().getCurrentBindingsEntry();
        AttributeBinding attr = (AttributeBinding)bindings.getControlBinding("Photo");
        if (attr != null){
            BlobDomain blob =(BlobDomain) attr.getInputValue();
            try{
                IOUtils.copy(blob.getInputStream(), outputStream);
                blob.closeInputStream();
                outputStream.flush();
            }
            catch (IOException e){
                e.printStackTrace();
                FacesMessage msg = new FacesMessage(FacesMessage.SEVERITY_ERROR,e.getMessage(),"Error");
                FacesContext.getCurrentInstance().addMessage(null, msg);
            }
        }

    }
    
    
    
    
}
