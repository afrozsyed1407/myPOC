package view.Bean;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import java.sql.SQLException;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.event.ValueChangeEvent;

import oracle.adf.model.BindingContext;
import oracle.adf.model.binding.DCIteratorBinding;

import oracle.adf.view.rich.component.rich.input.RichInputFile;

import oracle.binding.BindingContainer;
import oracle.binding.OperationBinding;

import oracle.jbo.domain.BlobDomain;

import org.apache.myfaces.trinidad.model.UploadedFile;

public class myBean {
    private RichInputFile fileInputBind;

    public myBean() {
    }

    public void uploadEmpImage(ValueChangeEvent valueChangeEvent) {
        try
        {
          UploadedFile file = (UploadedFile) valueChangeEvent.getNewValue();
          BindingContainer bindings = BindingContext.getCurrent().getCurrentBindingsEntry();
          DCIteratorBinding iter = (DCIteratorBinding) bindings.get("EmployeesView1Iterator");
          iter.getCurrentRow().setAttribute("Photo", newBlobDomainForInputStream(file.getInputStream()));
          OperationBinding op = bindings.getOperationBinding("Commit");
          op.execute();
          // showing message on screen that image uploaded sucessfully
          FacesContext context = FacesContext.getCurrentInstance();
          context.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Image Uploaded Successfully..", null));
          //  resetting the inputfile component
            this.getFileInputBind().resetValue();

        }
        catch (Exception e)
        {
          // TODO: Add catch code
          e.printStackTrace();
        }
        
        }
        
        private BlobDomain newBlobDomainForInputStream(InputStream in) throws SQLException, IOException {
          BlobDomain b = new BlobDomain();
          OutputStream out = b.getBinaryOutputStream();
          writeInputStreamToOutputStream(in, out);
          in.close();
          out.close();
          return b;
        }
        
        private void writeInputStreamToOutputStream(InputStream in, OutputStream out) throws IOException {
          byte[] buffer = new byte[8192];
          int bytesRead = 0;
          while ((bytesRead = in.read(buffer, 0, 8192)) != -1) {
              out.write(buffer, 0, bytesRead);
          }
        }

    public void setFileInputBind(RichInputFile fileInputBind) {
        this.fileInputBind = fileInputBind;
    }

    public RichInputFile getFileInputBind() {
        return fileInputBind;
    }
}
