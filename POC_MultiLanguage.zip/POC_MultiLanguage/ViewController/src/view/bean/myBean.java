package view.bean;

import java.util.Locale;
import java.util.Map;

import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;

import oracle.adf.share.ADFContext;

public class myBean {
    public myBean() {
    }

    public static void storeOnSession(String key, Object object){
        FacesContext ctx = FacesContext.getCurrentInstance();
        Map sessionState = ctx.getExternalContext().getSessionMap();
        sessionState.put(key, object);
    }
    public static void getFromSession(String key){
        FacesContext ctx = FacesContext.getCurrentInstance();
        Map sessionState = ctx.getExternalContext().getSessionMap();
        sessionState.get(key);
    }
    public static String switchLanguage(String lang){
        storeOnSession("lang",lang);
        FacesContext context = FacesContext.getCurrentInstance();
        Locale locale = new Locale(lang);
        context.getViewRoot().setLocale(locale);
        ADFContext.getCurrent().setLocale(locale);
        return null;
    }

    public String englishStitch() {
        // Add event code here...
        switchLanguage("en");
        return null;
    }

    public String switcchArabic() {
        // Add event code here...
        switchLanguage("ar");
        return null;
    }

    public String selectTelugu() {
        // Add event code here...
        switchLanguage("te");
        return null;
    }

    public String selectHindi() {
        // Add event code here...
        switchLanguage("hi");
        return null;
    }
}
