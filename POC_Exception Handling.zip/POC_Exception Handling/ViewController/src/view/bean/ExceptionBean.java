package view.bean;

import javax.faces.event.ActionEvent;

import oracle.adf.model.BindingContext;

import oracle.adf.model.binding.DCBindingContainer;

import oracle.jbo.JboException;

public class ExceptionBean {
    public ExceptionBean() {
    }

    public void callExceptions(ActionEvent actionEvent) {
        // Add event code here...
        JboException ex = new JboException("You can show exception Here also !!!!!");
                BindingContext bctx = BindingContext.getCurrent();
                ((DCBindingContainer)bctx.getCurrentBindingsEntry()).reportException(ex);
    }
}
