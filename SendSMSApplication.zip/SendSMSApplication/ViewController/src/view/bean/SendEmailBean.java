package view.bean;

import java.util.Map;

import javax.faces.event.ActionEvent;

import oracle.adf.view.rich.component.rich.input.RichInputText;

import oracle.binding.OperationBinding;

import view.CommonCode.ADFUtil;

public class SendEmailBean {
    private RichInputText toEmailAddress;
    private RichInputText subject;
    private RichInputText emailBody;

    public SendEmailBean() {
    }

    public void sendEmail(ActionEvent actionEvent) {
        System.out.println("Entered sendEmailApp");
        String toAddress = this.getToEmailAddress().getValue().toString();
        String emailSubj = this.getSubject().getValue().toString();
        String emailBody = this.getEmailBody().getValue().toString();
        OperationBinding emailBindOP = ADFUtil.findOperation("sendSms");
        emailBindOP.getParamsMap().put("toAddress", toAddress);
        emailBindOP.getParamsMap().put("subject", emailSubj);
        emailBindOP.getParamsMap().put("emailBody", emailBody);
        String result = (String) emailBindOP.execute();
        System.out.println("++++"+result+"++++");
        //        resultMap = (Map) smsBindOP.execute();
    }

    public void setToEmailAddress(RichInputText toEmailAddress) {
        this.toEmailAddress = toEmailAddress;
    }

    public RichInputText getToEmailAddress() {
        return toEmailAddress;
    }

    public void setSubject(RichInputText subject) {
        this.subject = subject;
    }

    public RichInputText getSubject() {
        return subject;
    }

    public void setEmailBody(RichInputText emailBody) {
        this.emailBody = emailBody;
    }

    public RichInputText getEmailBody() {
        return emailBody;
    }
}
