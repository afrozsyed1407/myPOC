package view.bean;

import java.util.HashMap;

import java.util.List;
import java.util.Map;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;

import oracle.adf.view.rich.component.rich.input.RichInputText;
import oracle.adf.view.rich.component.rich.output.RichOutputText;
import oracle.adf.model.BindingContext;
import oracle.adf.view.rich.context.AdfFacesContext;

import oracle.binding.BindingContainer;
import oracle.binding.OperationBinding;

import view.CommonCode.ADFUtil;
import view.CommonCode.ValidationUtil;

public class SendSmsBean {
    private RichInputText numberField;
    private RichInputText messageField;
    private RichOutputText outMessage;

    public SendSmsBean() {
    }

    public void sendSmsAction(ActionEvent actionEvent) {
        System.out.println("entered send SMS");
        String number = this.getNumberField()
                            .getValue()
                            .toString();
        String message = this.getMessageField()
                             .getValue()
                             .toString();
        System.out.println("number :::" + number + ": Message ::" + message);
        HashMap<String, String> inputMap = new HashMap<String, String>();
        Map resultMap = new HashMap();
        inputMap.put("authorization",
                     "lF4bH07urZYSUCiJQcGzaxnOP32hjtRdN1DwA5Vms9ykK6IMov2eafSlZq9UQg3WL574tocFdMTiN86s");
        inputMap.put("sender_id", "TXTIND");
        inputMap.put("message", message);
        inputMap.put("language", "english");
        inputMap.put("route", "p");
        inputMap.put("numbers", number);

        OperationBinding smsBindOP = ADFUtil.findOperation("sendSms");
        smsBindOP.getParamsMap().put("inputMap", inputMap);
        resultMap = (Map) smsBindOP.execute();
        System.out.println("Result Map:::"+ resultMap);
        if (!ValidationUtil.isNullOrEmpty(resultMap)) {
            if (!ValidationUtil.isNullOrEmpty(resultMap.get("message"))) {
                boolean returnStmt = (Boolean)resultMap.get("return");
                if(returnStmt){
                    this.getOutMessage().setValue("SMS Send Sucessfully");
                    FacesContext context = FacesContext.getCurrentInstance();
                            context.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, " SMS Send Sucessfully..", null));
                }
                List<String> messageResp = (List<String>) resultMap.get("message");
                System.out.println("++++"+messageResp);
                
            }
        }
        AdfFacesContext.getCurrentInstance().addPartialTarget(this.getOutMessage());

    }

    public void setNumberField(RichInputText numberField) {
        this.numberField = numberField;
    }

    public RichInputText getNumberField() {
        return numberField;
    }

    public void setMessageField(RichInputText messageField) {
        this.messageField = messageField;
    }

    public RichInputText getMessageField() {
        return messageField;
    }

    public void setOutMessage(RichOutputText outMessage) {
        this.outMessage = outMessage;
    }

    public RichOutputText getOutMessage() {
        return outMessage;
    }
}
