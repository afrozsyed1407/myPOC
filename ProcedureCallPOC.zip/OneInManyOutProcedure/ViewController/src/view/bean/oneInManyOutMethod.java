package view.bean;

import java.util.ArrayList;

import javax.faces.application.Application;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;


import oracle.adf.model.binding.DCBindingContainer;

import oracle.binding.OperationBinding;


public class oneInManyOutMethod {
    public oneInManyOutMethod() {
    }
    private Number EmpId;
    private String eMail,fName,lName,deptId,salary;

    public void oneInManyOutMethodCode(ActionEvent actionEvent) {
        // Add event code here...
        
        FacesContext context = FacesContext.getCurrentInstance();
        Application app = context.getApplication();

        DCBindingContainer binding = (DCBindingContainer) app.evaluateExpressionGet(context, "#{bindings}",DCBindingContainer.class);

        // Call AM insContData Method

        OperationBinding callAmMethod =
        binding.getOperationBinding("callStoredProcOutParam");
        callAmMethod.getParamsMap().put("EmpId",getEmpId());


        callAmMethod.execute();

                ArrayList<String> emplist1 = (ArrayList<String>)callAmMethod.getResult();

               this.setFName(emplist1.get(0));
               this.setLName(emplist1.get(1));
               this.setEMail(emplist1.get(2));
               this.setDeptId(emplist1.get(3));
               this.setSalary(emplist1.get(4));

           

    }

    public void setEmpId(Number EmpId) {
        this.EmpId = EmpId;
    }

    public Number getEmpId() {
        return EmpId;
    }

    public void setEMail(String eMail) {
        this.eMail = eMail;
    }

    public String getEMail() {
        return eMail;
    }

    public void setFName(String fName) {
        this.fName = fName;
    }

    public String getFName() {
        return fName;
    }

    public void setLName(String lName) {
        this.lName = lName;
    }

    public String getLName() {
        return lName;
    }

    public void setDeptId(String deptId) {
        this.deptId = deptId;
    }

    public String getDeptId() {
        return deptId;
    }

    public void setSalary(String salary) {
        this.salary = salary;
    }

    public String getSalary() {
        return salary;
    }
}
